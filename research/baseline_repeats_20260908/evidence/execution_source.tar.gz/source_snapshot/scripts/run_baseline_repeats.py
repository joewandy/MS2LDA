"""Run the five approved validation-only baseline fits with bounded concurrency.

One CPU Tomotopy queue runs alongside one GPU/annotation queue. Each fit has a
fresh sealed view, immutable execution-source snapshot and durable stage log.
This is a fixed experiment runner, not a model-selection or tuning framework.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from contextlib import nullcontext
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

from benchmarks.neural_ms2lda.utils import sha256_file, write_json

REPO = Path(__file__).resolve().parents[1]


def utc_now():
    """Record wall-clock provenance separately from measured training durations."""
    return datetime.now(timezone.utc).isoformat()


def snapshot_source(root: Path):
    """Freeze executed Python bytes so concurrent editorial work cannot affect fits."""
    destination = root / "source_snapshot"
    destination.mkdir()
    sources = []
    for package in ("benchmarks", "scripts", "MS2LDA"):
        for source in sorted((REPO / package).rglob("*.py")):
            relative = source.relative_to(REPO)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            sources.append({"path": str(relative), "sha256": sha256_file(target)})
    for name in ("environment.yml", "pyproject.toml"):
        shutil.copy2(REPO / name, destination / name)
        sources.append({"path": name, "sha256": sha256_file(destination / name)})
    git = shutil.which("git")
    if git is None:
        raise RuntimeError("Git is required to record execution-source provenance")
    revision = subprocess.check_output(  # noqa: S603 - fixed read-only Git command
        [git, "rev-parse", "HEAD"], cwd=REPO, text=True
    ).strip()
    status = subprocess.check_output(  # noqa: S603 - fixed read-only Git command
        [git, "status", "--porcelain=v1"], cwd=REPO, text=True
    )
    write_json(
        root / "source_manifest.json",
        {
            "created_utc": utc_now(),
            "revision": revision,
            "dirty": bool(status.strip()),
            "git_status": status,
            "python": sys.executable,
            "sources": sources,
        },
    )
    return destination


def run_stage(root, snapshot, run, name, module, arguments):
    """Persist an attempt record before launch and leave failed outputs intact."""
    log_path = root / "logs" / f"{run.name}.{name}.log"
    record_path = root / "stages" / f"{run.name}.{name}.json"
    command = [sys.executable, "-u", "-m", module, *map(str, arguments)]
    record = {
        "run": str(run),
        "stage": name,
        "attempt": 1,
        "command": command,
        "cwd": str(snapshot),
        "started_utc": utc_now(),
        "log": str(log_path),
        "status": "running",
    }
    environment = dict(os.environ, PYTHONPATH=str(snapshot), PYTHONUNBUFFERED="1")
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(  # noqa: S603 - fixed modules, no shell evaluation
            command, cwd=snapshot, env=environment, stdout=log, stderr=subprocess.STDOUT
        )
        record["pid"] = process.pid
        write_json(record_path, record)
        print(f"START {run.name} {name} pid={process.pid} log={log_path}", flush=True)
        code = process.wait()
    record.update(
        finished_utc=utc_now(),
        return_code=code,
        status="complete" if code == 0 else "failed",
    )
    write_json(record_path, record)
    print(f"END {run.name} {name} exit={code}", flush=True)
    if code:
        raise RuntimeError(f"{run.name}/{name} failed; retain its log and artifacts")


def run_queue(kind, seeds, root, snapshot, prepared, assets, annotation_lock):
    """Run each prescribed fit once; never replace a failed seed with another."""
    failures = []
    for seed in seeds:
        run = root / "real" / f"{kind}_seed{seed}_attempt1"
        try:
            run_stage(
                root,
                snapshot,
                run,
                "seal",
                "scripts.prepare_msnlib_validation_view",
                ["--run", run, "--prepared-run", prepared],
            )
            with annotation_lock if kind == "etm" else nullcontext():
                if kind == "etm":
                    module = "scripts.run_etm_controls"
                    arguments = [
                        "train",
                        "--run",
                        run,
                        "--method",
                        "etm",
                        "--device",
                        "cuda",
                        "--epochs",
                        120,
                        "--batch-size",
                        256,
                    ]
                else:
                    module = "scripts.run_tomotopy_validation"
                    arguments = ["--run", run]
                run_stage(
                    root,
                    snapshot,
                    run,
                    "fit_validation",
                    module,
                    [*arguments, "--training-seed", seed],
                )
            with annotation_lock:
                run_stage(
                    root,
                    snapshot,
                    run,
                    "chemistry",
                    "benchmarks.neural_ms2lda.chemical",
                    [
                        "--run",
                        run,
                        "--data-root",
                        assets,
                        "--method",
                        kind,
                        "--split",
                        "validation",
                    ],
                )
        except RuntimeError as error:
            failures.append({"kind": kind, "training_seed": seed, "error": str(error)})
    return failures


def main():
    """Freeze sources and run the approved three-LDA/two-ETM fit inventory."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--prepared-run", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    root.mkdir(parents=True, exist_ok=False)
    (root / "logs").mkdir()
    (root / "stages").mkdir()
    snapshot = snapshot_source(root)
    write_json(
        root / "driver.json",
        {"pid": os.getpid(), "started_utc": utc_now(), "status": "running"},
    )
    annotation_lock = Lock()
    with ThreadPoolExecutor(max_workers=2) as workers:
        queues = [
            workers.submit(
                run_queue,
                kind,
                seeds,
                root,
                snapshot,
                args.prepared_run.resolve(),
                args.data_root.resolve(),
                annotation_lock,
            )
            for kind, seeds in (("tomotopy", (11, 23, 42)), ("etm", (7012, 7024)))
        ]
        failures = [failure for queue in queues for failure in queue.result()]
    write_json(
        root / "driver.json",
        {
            "pid": os.getpid(),
            "finished_utc": utc_now(),
            "status": "failed" if failures else "complete",
            "failures": failures,
        },
    )
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
