"""Train and evaluate the archived leave-one-out Contextual Sparse ETM.

The current whole-spectrum model uses ``run_minimal_etm``; this historical path uses:
normalized spectral-word counts are encoded, contextual top-2 evidence shifts
the Gaussian posterior mean, 1.5-entmax produces ``theta``, and the
channel-balanced ETM decoder produces ``beta``.  Training minimizes the raw
pseudo-count reconstruction loss plus the analytic Gaussian KL divergence.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, NamedTuple

import numpy as np
import torch

from benchmarks.neural_ms2lda.contextual_sparse_etm import ContextualSparseETM
from benchmarks.neural_ms2lda.diagnostics import model_selection_diagnostics
from benchmarks.neural_ms2lda.model_evaluation import (
    MODEL_SELECTION_EVALUATION_PROTOCOL,
    completion_metrics,
    entropy_diagnostics,
    mixture_distribution_summary,
    save_validation,
    score_chemical_validation,
    theta_support_diagnostics,
    topic_word_diagnostics,
)
from benchmarks.neural_ms2lda.model_inference import (
    infer_document_topics as infer_document_topic_mixtures,
)
from benchmarks.neural_ms2lda.reproducibility import (
    MemoryState,
    configure_deterministic_execution,
    flatten_support_summary,
    normalize_probability_rows,
    read_json_object,
    resolve_torch_device,
    runtime_memory_metrics,
    sample_runtime_memory,
    sha256_file,
    validate_probability_matrix,
    write_csv_rows,
)
from benchmarks.neural_ms2lda.study_protocol import (
    METHOD,
    MODEL_DISPLAY_NAME,
    TRAINING_ACCESS_AUDIT_FILENAME,
)
from benchmarks.neural_ms2lda.topic_model_training import (
    dense_normalized,
    raw_count_reconstruction_loss,
)
from benchmarks.neural_ms2lda.utils import (
    atomic_torch_save,
    write_json,
)
from benchmarks.neural_ms2lda.validation_data import load_validation_inputs

if TYPE_CHECKING:
    from collections.abc import Sequence

    import scipy.sparse as sp

LEARNING_RATE = 0.005
WEIGHT_DECAY = 1.2e-6
EPSILON = 1e-12


class TrainingSettings(NamedTuple):
    """Transparent command-line settings with no behavior or hidden defaults."""

    epochs: int
    batch_size: int
    threads: int
    requested_seed: int | None = None


class ValidationData(NamedTuple):
    """Arrays and metadata loaded from the frozen validation-only view."""

    run_directory: Path
    train: sp.csr_matrix
    observed: sp.csr_matrix
    completion: sp.csr_matrix
    full: sp.csr_matrix
    records: list[dict[str, Any]]
    vocabulary: list[str]
    embeddings: np.ndarray
    fragment_mask: np.ndarray
    topics: int
    data_seed: int
    input_manifest: dict[str, Any]


class TrainingOutcome(NamedTuple):
    """The two small pieces of state needed after fitting."""

    history: list[dict[str, Any]]
    memory_state: MemoryState


class ExecutionState(NamedTuple):
    """Resolved execution values that are recorded in the run configuration."""

    training_seed: int
    device: torch.device


def resolve_training_seed(data_seed: int, requested_seed: int | None) -> int:
    """Return the frozen default training seed or an explicit stability seed."""
    training_seed = (
        int(data_seed) + 7001 if requested_seed is None else int(requested_seed)
    )
    if training_seed < 0:
        message = "training seed must be non-negative"
        raise ValueError(message)
    return training_seed


def _validate_settings(settings: TrainingSettings) -> None:
    """Reject nonsensical execution settings before opening or writing a run."""
    if settings.epochs <= 0:
        message = "epochs must be positive"
        raise ValueError(message)
    if settings.batch_size <= 0:
        message = "batch size must be positive"
        raise ValueError(message)
    if settings.threads <= 0:
        message = "threads must be positive"
        raise ValueError(message)


def _load_validation_data(
    run_directory: Path,
) -> ValidationData:
    """Load and cross-check the frozen training and validation arrays."""
    data = load_validation_inputs(run_directory)
    return ValidationData(
        run_directory=run_directory,
        train=data.train,
        observed=data.observed,
        completion=data.completion,
        full=data.full,
        records=data.records,
        vocabulary=data.vocabulary,
        embeddings=data.embeddings,
        fragment_mask=np.asarray(
            [word.startswith("frag@") for word in data.vocabulary], dtype=bool
        ),
        topics=int(data.protocol["model"]["num_topics"]),
        data_seed=int(data.protocol["seed"]),
        input_manifest=data.input_manifest,
    )


def _run_configuration(
    data: ValidationData,
    settings: TrainingSettings,
    execution: ExecutionState,
) -> dict[str, Any]:
    """Return a plain-language, machine-readable specification of this run."""
    return {
        "model_name": MODEL_DISPLAY_NAME,
        "artifact_method_id": METHOD,
        "evidence": "frozen MSnLib training plus validation only",
        "prepared_run": data.input_manifest["prepared_run"],
        "published_base": "Embedded Topic Model",
        "topics": data.topics,
        "fixed_train_only_sgns_dimensions": int(data.embeddings.shape[1]),
        "fragment_loss_beta_mass": [0.5, 0.5],
        "hidden_dimensions": 800,
        "context_parameters": 1,
        "context_top_k": 2,
        "context_temperature": 1.0,
        "contextual_evidence": (
            "count-weighted top-2 assignments from leave-one-out token context"
        ),
        "posterior_offset": "centered log of evidence plus a fixed 1/K pseudocount",
        "evidence_pseudocount": "1/K",
        "numerical_probability_floor": EPSILON,
        "document_topic_transform": "1.5-entmax",
        "entmax_alpha": 1.5,
        "variational_posterior": "diagonal Gaussian with analytic standard-normal KL",
        "reconstruction": "raw pseudo-count multinomial negative log-likelihood",
        "epochs": settings.epochs,
        "batch_size": settings.batch_size,
        "optimizer": "Adam",
        "learning_rate": LEARNING_RATE,
        "weight_decay": WEIGHT_DECAY,
        "data_split_seed": data.data_seed,
        "training_seed": execution.training_seed,
        "device": str(execution.device),
        "threads": settings.threads,
        "stopping_rule": "fixed epochs or immediate non-finite loss/gradient",
        "candidate_test_artifacts_accessed": False,
    }


def _train_one_epoch(
    model: ContextualSparseETM,
    optimizer: torch.optim.Optimizer,
    train: sp.csr_matrix,
    random_generator: np.random.Generator,
    batch_size: int,
) -> dict[str, float]:
    """Apply one epoch of the report's reconstruction-plus-KL objective."""
    model.train()
    device = model.rho.device
    reconstruction_values: list[float] = []
    kl_values: list[float] = []
    gradient_values: list[float] = []
    mass_values: list[float] = []
    epoch_started = time.perf_counter()
    order = random_generator.permutation(train.shape[0])
    for start in range(0, len(order), batch_size):
        rows = order[start : start + batch_size]
        x = dense_normalized(train, rows, device)
        theta, kl = model.document_topic_mixture(x, sample=True)
        beta = model.topic_word_distribution()
        reconstruction, effective_mass = raw_count_reconstruction_loss(
            theta,
            beta,
            train[rows],
            device,
        )
        objective = reconstruction + kl.mean()
        if not torch.isfinite(objective):
            message = "Contextual Sparse ETM produced a non-finite loss"
            raise FloatingPointError(message)

        optimizer.zero_grad(set_to_none=True)
        objective.backward()
        if not all(
            parameter.grad is None or torch.all(torch.isfinite(parameter.grad)).item()
            for parameter in model.parameters()
        ):
            message = "Contextual Sparse ETM produced non-finite gradients"
            raise FloatingPointError(message)
        gradient_norm = torch.nn.utils.clip_grad_norm_(
            model.parameters(),
            max_norm=float("inf"),
        )
        optimizer.step()

        reconstruction_values.append(float(reconstruction.detach().cpu()))
        kl_values.append(float(kl.mean().detach().cpu()))
        gradient_values.append(float(gradient_norm.detach().cpu()))
        mass_values.append(effective_mass)

    mean_reconstruction = float(np.mean(reconstruction_values))
    mean_kl = float(np.mean(kl_values))
    return {
        "reconstruction": mean_reconstruction,
        "kl": mean_kl,
        "reconstruction_to_kl_ratio": mean_reconstruction / max(mean_kl, EPSILON),
        "mean_gradient_norm": float(np.mean(gradient_values)),
        "mean_effective_document_mass": float(np.mean(mass_values)),
        "context_scale": float(model.context_scale.detach().cpu()),
        "seconds": time.perf_counter() - epoch_started,
    }


@torch.inference_mode()
def infer_contextual_evidence(
    model: ContextualSparseETM,
    matrix: sp.csr_matrix,
    *,
    batch_size: int,
) -> np.ndarray:
    """Infer the auditable evidence matrix ``r`` from ``eq:document-evidence``."""
    model.eval()
    device = model.rho.device
    batches: list[np.ndarray] = []
    for start in range(0, matrix.shape[0], batch_size):
        rows = np.arange(
            start,
            min(start + batch_size, matrix.shape[0]),
            dtype=np.int64,
        )
        x = dense_normalized(matrix, rows, device)
        r = model.contextual_evidence(x)
        batches.append(r.cpu().numpy().astype(np.float32))
    return np.concatenate(batches)


def _artifact_record(path: Path, *, relative_to: Path) -> dict[str, object]:
    """Return path, byte count, and digest for one locally retained artifact."""
    return {
        "path": path.relative_to(relative_to).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def _evaluate_and_persist(
    model: ContextualSparseETM,
    data: ValidationData,
    output: Path,
    settings: TrainingSettings,
    training: TrainingOutcome,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Run deterministic validation, calculate metrics, and save model outputs."""
    with torch.inference_mode():
        beta = normalize_probability_rows(
            model.topic_word_distribution().cpu().numpy(),
            name="contextual sparse ETM validation beta",
        )
    theta_observed, observed_throughput = infer_document_topic_mixtures(
        model,
        data.observed,
        batch_size=settings.batch_size,
    )
    theta_full, full_throughput = infer_document_topic_mixtures(
        model,
        data.full,
        batch_size=settings.batch_size,
    )
    evidence = infer_contextual_evidence(
        model,
        data.full,
        batch_size=settings.batch_size,
    )
    validate_probability_matrix(theta_observed, name="validation observed theta")
    validate_probability_matrix(theta_full, name="validation full theta")
    validate_probability_matrix(evidence, name="validation contextual evidence")

    diagnostics = model_selection_diagnostics(
        theta_full,
        beta,
        data.vocabulary,
        MODEL_SELECTION_EVALUATION_PROTOCOL,
    )
    support = theta_support_diagnostics(theta_full)
    evidence_support = theta_support_diagnostics(evidence)
    _, top_words = topic_word_diagnostics(beta, data.vocabulary)
    metrics = {
        "document_completion": completion_metrics(
            theta_observed,
            beta,
            data.completion,
            data.records,
        ),
        **diagnostics,
        "theta_support": support,
        "context_evidence_support": evidence_support,
        "theta_distribution": mixture_distribution_summary(theta_full),
        "theta_information": entropy_diagnostics(theta_full),
        "finite_stable": bool(
            np.all(np.isfinite(beta))
            and np.all(np.isfinite(theta_observed))
            and np.all(np.isfinite(theta_full))
            and np.all(np.isfinite(evidence)),
        ),
        "learned_context_scale": float(model.context_scale.detach().cpu()),
        "runtime": {
            "training_wall_seconds": float(
                sum(float(row["seconds"]) for row in training.history),
            ),
            "validation_observed_spectra_per_second": observed_throughput,
            "validation_full_spectra_per_second": full_throughput,
            "memory": runtime_memory_metrics(
                training.memory_state,
                model.rho.device,
            ),
        },
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
    }

    weights_path = output / "weights.pt"
    atomic_torch_save(
        weights_path,
        {key: value.detach().cpu() for key, value in model.state_dict().items()},
    )
    write_csv_rows(output / "top_words.csv", top_words)
    write_csv_rows(
        output / "theta_support_summary.csv",
        [flatten_support_summary(support)],
    )
    write_csv_rows(
        output / "context_evidence_support_summary.csv",
        [flatten_support_summary(evidence_support)],
    )
    write_json(
        output / "duplicate_component_summary.json",
        {
            "duplicate_components": diagnostics["topic_inventory"][
                "duplicate_components"
            ],
            "catastrophic_duplicate_component": diagnostics["topic_inventory"][
                "catastrophic_duplicate_component"
            ],
            "largest_strict_duplicate_component": diagnostics["topic_inventory"][
                "largest_strict_duplicate_component"
            ],
        },
    )
    write_json(
        output / "fragment_mass_summary.json",
        diagnostics["fragment_probability_mass"],
    )
    save_validation(data.run_directory, METHOD, beta, theta_full, metrics)
    validation_output = data.run_directory / "validation_evaluation" / METHOD

    provenance = {
        "validation_inputs": data.input_manifest,
        "candidate_test_artifacts_accessed": False,
        "candidate_test_metrics_inspected": False,
        "local_artifacts": [
            _artifact_record(path, relative_to=data.run_directory)
            for path in (
                weights_path,
                validation_output / "beta.npy",
                validation_output / "validation_full_theta.npy",
                validation_output / "complete.json",
            )
        ],
    }
    write_json(output / "provenance.json", provenance)
    return metrics, provenance


def train_real_validation(
    real_run: Path,
    *,
    device: torch.device,
    settings: TrainingSettings,
) -> dict[str, Any]:
    """Train the model on frozen training data and evaluate validation only."""
    _validate_settings(settings)
    run_directory = real_run.expanduser().resolve(strict=True)
    output = run_directory / "models" / METHOD
    result_path = output / "result.json"
    if result_path.is_file():
        return read_json_object(result_path)

    data = _load_validation_data(run_directory)
    training_seed = resolve_training_seed(data.data_seed, settings.requested_seed)
    configure_deterministic_execution(training_seed, settings.threads)
    model = ContextualSparseETM(
        data.embeddings,
        data.topics,
        data.fragment_mask,
        hidden=800,
    ).to(device)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
    )
    random_generator = np.random.default_rng(training_seed + 18)
    output.mkdir(parents=True, exist_ok=True)
    write_json(
        output / "config.json",
        _run_configuration(
            data,
            settings,
            ExecutionState(
                training_seed=training_seed,
                device=device,
            ),
        ),
    )
    write_json(output / TRAINING_ACCESS_AUDIT_FILENAME, data.input_manifest)

    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    memory_state = sample_runtime_memory()
    history: list[dict[str, Any]] = []
    for epoch_index in range(settings.epochs):
        epoch_metrics = _train_one_epoch(
            model,
            optimizer,
            data.train,
            random_generator,
            settings.batch_size,
        )
        row = {"epoch": epoch_index + 1, **epoch_metrics}
        history.append(row)
        memory_state = sample_runtime_memory(memory_state)
        write_csv_rows(output / "training_history.csv", history)
        print(  # noqa: T201
            "CONTEXTUAL_SPARSE_ETM_EPOCH",
            json.dumps(row, sort_keys=True),
            flush=True,
        )

    model.eval()
    metrics, provenance = _evaluate_and_persist(
        model,
        data,
        output,
        settings,
        TrainingOutcome(history=history, memory_state=memory_state),
    )
    result = {
        "model": MODEL_DISPLAY_NAME,
        "method": METHOD,
        "parameters": metrics["parameters"],
        "config": read_json_object(output / "config.json"),
        "metrics": metrics,
        "provenance": provenance,
    }
    write_json(result_path, result)
    return result


def score_real_validation(real_run: Path, data_root: Path) -> dict[str, Any]:
    """Run the unchanged leakage-controlled MAG/SOS validation evaluation."""
    return score_chemical_validation(
        real_run.expanduser().resolve(),
        data_root.expanduser().resolve(),
        METHOD,
    )


def main(argv: Sequence[str] | None = None) -> int:
    """Run training/inference or chemical validation scoring."""
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    train = commands.add_parser("train")
    train.add_argument("--real-run", required=True, type=Path)
    train.add_argument("--epochs", type=int, default=120)
    train.add_argument("--batch-size", type=int, default=256)
    train.add_argument("--device", choices=("auto", "cpu", "cuda"), default="cuda")
    train.add_argument("--threads", type=int, default=6)
    train.add_argument(
        "--training-seed",
        type=int,
        help="override only model initialization and training order",
    )
    score = commands.add_parser("chemical")
    score.add_argument("--real-run", required=True, type=Path)
    score.add_argument("--data-root", required=True, type=Path)
    args = parser.parse_args(argv)
    if args.command == "train":
        result = train_real_validation(
            args.real_run,
            device=resolve_torch_device(args.device),
            settings=TrainingSettings(
                epochs=args.epochs,
                batch_size=args.batch_size,
                threads=args.threads,
                requested_seed=args.training_seed,
            ),
        )
    elif args.command == "chemical":
        result = score_real_validation(args.real_run, args.data_root)
    else:
        message = "unknown Contextual Sparse ETM command"
        raise RuntimeError(message)
    print(json.dumps(result, indent=2, sort_keys=True), flush=True)  # noqa: T201
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
