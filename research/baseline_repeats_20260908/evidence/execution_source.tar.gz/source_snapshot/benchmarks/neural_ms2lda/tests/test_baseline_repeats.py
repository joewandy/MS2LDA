"""Repeated baseline fits vary optimization randomness, not the data protocol."""

import pytest
import torch

from benchmarks.neural_ms2lda.baseline_repeats import (
    baseline_fit_identity,
    require_cached_fit,
    resolve_training_seed,
)
from benchmarks.neural_ms2lda.tomotopy import train_tomotopy
from benchmarks.neural_ms2lda.utils import sha256_file
from scripts.prepare_msnlib_validation_view import create_validation_view
from scripts.run_etm_controls import train_control

from .test_workflow import _prepare_mini_prepared_source


def test_training_seed_defaults_and_overrides():
    protocol = {"seed": 42}
    assert resolve_training_seed(protocol, None) == 42
    assert resolve_training_seed(protocol, None, offset=7001) == 7043
    assert resolve_training_seed(protocol, 7012, offset=7001) == 7012
    assert resolve_training_seed(protocol, 7024, offset=7001) + 18 == 7042
    assert protocol == {"seed": 42}


@pytest.mark.parametrize("seed", [-1, True, 2**31, 1.5])
def test_training_seed_rejects_invalid_values(seed):
    with pytest.raises(ValueError, match="training seed"):
        resolve_training_seed({"seed": 42}, seed)


def test_baseline_cache_rejects_wrong_seed_recipe_and_inputs(tmp_path):
    prepared, _ = _prepare_mini_prepared_source(tmp_path)
    run = tmp_path / "repeat"
    create_validation_view(run, prepared, expected_topics=4)
    expected = baseline_fit_identity(run, 11, {"epochs": 1})
    require_cached_fit({"fit_identity": expected}, expected)
    for field, changed in (
        ("training_seed", 23),
        ("recipe", {"epochs": 2}),
        ("input_sha256", {}),
    ):
        with pytest.raises(RuntimeError, match="cached baseline"):
            require_cached_fit({"fit_identity": {**expected, field: changed}}, expected)
    with (prepared / "data/train.npz").open("ab") as handle:
        handle.write(b"modified after sealing")
    with pytest.raises(RuntimeError, match="manifest-owned input changed"):
        baseline_fit_identity(run, 11, {"epochs": 1})


def test_etm_repeat_seed_and_shuffle_leave_protocol_unchanged(tmp_path):
    prepared, _ = _prepare_mini_prepared_source(tmp_path)
    run = tmp_path / "etm"
    create_validation_view(run, prepared, expected_topics=4)
    before = sha256_file(prepared / "protocol.json")
    kwargs = dict(method="etm", device=torch.device("cpu"), epochs=1, batch_size=4)
    result = train_control(run, **kwargs, training_seed=7012)
    assert result["config"]["seed"] == 7012
    assert result["config"]["shuffle_seed"] == 7030
    assert sha256_file(prepared / "protocol.json") == before
    assert train_control(run, **kwargs, training_seed=7012) == result
    with pytest.raises(RuntimeError, match="cached baseline"):
        train_control(run, **kwargs, training_seed=7024)
    assert not list((run / "data").glob("test*"))


def test_tomotopy_repeat_seed_leaves_protocol_unchanged(tmp_path):
    prepared, protocol = _prepare_mini_prepared_source(tmp_path)
    run = tmp_path / "lda"
    create_validation_view(run, prepared, expected_topics=4)
    before = sha256_file(prepared / "protocol.json")
    result = train_tomotopy(run, protocol, training_seed=11)
    assert result["training_seed"] == 11
    assert sha256_file(prepared / "protocol.json") == before
    assert train_tomotopy(run, protocol, training_seed=11) == result
    with pytest.raises(RuntimeError, match="cached baseline"):
        train_tomotopy(run, protocol, training_seed=23)
    assert not list((run / "data").glob("test*"))
