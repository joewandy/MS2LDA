"""Small, standard-library-only summaries for the current paper's comparison.

Each input row describes one completed fit, not one spectrum or one motif.
We average fit-level statistics and use sample SD (denominator n - 1).
In particular, median_effective_topics is already a median over spectra;
its reported mean and SD describe variation of that median across fits.
"""

from __future__ import annotations

from collections import Counter
from statistics import mean, stdev

from .review_tables import number

BASELINE_SEEDS = {
    "Tomotopy LDA": (11, 23, 42),
    "canonical ETM": (7012, 7024, 7043),
}
BASELINE_LABELS = {"Tomotopy LDA": "Tomotopy LDA", "canonical ETM": "Plain ETM"}
COMPARISON_FIELDS = (
    ("evaluable_motifs", 1),
    ("useful_motifs", 1),
    ("mean_sos", 3),
    ("completion_nll", 3),
    ("median_effective_topics", 2),
)


def baseline_summaries(rows: list[dict]) -> dict[str, dict]:
    """Require the six declared baseline fits before producing uncertainty.

These checks guard the public report inventory. The evidence packager also
verifies raw artifacts, scientific input identities and fixed model recipes.
No partial inventory, synthetic run or historical fourth Tomotopy fit can
silently contribute to the current comparison.
    """
    expected = Counter(
        (model, seed) for model, seeds in BASELINE_SEEDS.items() for seed in seeds
    )
    actual = Counter((row["model"], int(row["training_seed"])) for row in rows)
    if actual != expected:
        raise ValueError("comparison needs exactly three declared fits per baseline")
    if len({row["run"] for row in rows}) != len(rows) or any(
        not row["run"] for row in rows
    ):
        raise ValueError("baseline runs must have distinct nonempty identities")
    for row in rows:
        for field, expected_value in (
            ("spectrum_topic_associations", 3889),
            ("completion_documents", 3888),
            ("completion_tokens", 1277983),
        ):
            if number(row, field) != expected_value:
                raise ValueError(f"baseline validation population differs: {field}")
        optimized, evaluable, useful = (
            number(row, key)
            for key in ("optimized_motifs", "evaluable_motifs", "useful_motifs")
        )
        if not (
            0 <= useful <= evaluable <= optimized <= 1000
            and all(value.is_integer() for value in (optimized, evaluable, useful))
        ):
            raise ValueError("baseline motif counts are inconsistent")
        if not 0 <= number(row, "mean_sos") <= 1:
            raise ValueError("baseline mean SOS must be in [0, 1]")
        if number(row, "completion_nll") < 0:
            raise ValueError("baseline completion NLL must be nonnegative")
        if not 1 <= number(row, "median_effective_topics") <= 1000:
            raise ValueError("baseline effective topic count must be in [1, K]")
    return {
        model: {
            "fits": 3,
            "training_seeds": list(seeds),
            **{
                field: {
                    "mean": mean(number(row, field) for row in rows_by_model),
                    "sample_sd": stdev(number(row, field) for row in rows_by_model),
                }
                for field, _ in COMPARISON_FIELDS
            },
        }
        for model, seeds in BASELINE_SEEDS.items()
        for rows_by_model in [[row for row in rows if row["model"] == model]]
    }


def comparison_cell(stat: dict, precision: int, *, highlight: bool = False) -> str:
    """Format mean +/- sample SD; bold is descriptive, not a significance test."""
    value = f"{stat['mean']:.{precision}f}" + r"\pm" + f"{stat['sample_sd']:.{precision}f}"
    return "$" + (r"\boldsymbol{" + value + "}" if highlight else value) + "$"


def comparison_table(baselines: dict[str, dict], selected: dict) -> list[str]:
    """Highlight observed extrema only for metrics with a stated direction.

Effective topic count is descriptive: a smaller value is not necessarily
better. Fit counts and this sparsity diagnostic are never ranked. Exact ties
at full numeric precision receive the same emphasis before display rounding.
    """
    entries = [(BASELINE_LABELS[name], baselines[name]) for name in BASELINE_SEEDS]
    entries.append(("Contextual Sparse ETM", selected))
    best = {
        field: select(stat[field]["mean"] for _, stat in entries)
        for field, select in (
            ("evaluable_motifs", max),
            ("useful_motifs", max),
            ("mean_sos", max),
            ("completion_nll", min),
        )
    }
    lines = []
    for label, stats in entries:
        if label == "Contextual Sparse ETM":
            lines.append(r"\midrule")
        cells = [label, "3"]
        cells.extend(
            comparison_cell(
                stats[field],
                precision,
                highlight=field in best and stats[field]["mean"] == best[field],
            )
            for field, precision in COMPARISON_FIELDS
        )
        lines.append(" & ".join(cells) + r" \\")
    return lines
